package com.example.dicodingevent
import DetailViewModel
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.example.dicodingevent.R
import com.example.dicodingevent.data.local.EventEntity

class DetailActivity : AppCompatActivity() {
    private lateinit var viewModel: DetailViewModel
    private lateinit var tvTitle: TextView
    private lateinit var tvSummary: TextView
    private lateinit var tvDescription: TextView
    private lateinit var tvLink: TextView
    private lateinit var imageCover: ImageView
    private lateinit var tvOwner: TextView
    private lateinit var tvBeginTime: TextView
    private lateinit var tvQuota: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var ivFavorite: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        // Inisialisasi elemen UI
        tvTitle = findViewById(R.id.tvTitle)
        tvSummary = findViewById(R.id.tvSummary)
        tvDescription = findViewById(R.id.tvDescription)
        tvLink = findViewById(R.id.tvLink)
        imageCover = findViewById(R.id.imageCover)
        tvOwner = findViewById(R.id.tvOwner)
        tvBeginTime = findViewById(R.id.tvBeginTime)
        tvQuota = findViewById(R.id.tvQuota)
        ivFavorite = findViewById(R.id.ivFavorite)
        progressBar = findViewById(R.id.progressBar)

        val eventId = intent.getIntExtra("EVENT_ID", -1)
        viewModel = ViewModelProvider(this).get(DetailViewModel::class.java)

        if (eventId != -1) {
            showLoading(true)
            viewModel.fetchEventDetail(eventId)
            viewModel.eventDetail.observe(this) { event ->
                event?.let {
                    tvTitle.text = it.name
                    tvSummary.text = it.summary
                    tvDescription.text = HtmlCompat.fromHtml(
                        it.description ?: "",
                        HtmlCompat.FROM_HTML_MODE_LEGACY
                    )
                    tvLink.text = it.link
                    Glide.with(this)
                        .load(it.mediaCover)
                        .into(imageCover)

                    // Menampilkan data tambahan: Penyelenggara, Waktu, Sisa Kuota
                    tvOwner.text = "Penyelenggara: ${it.ownerName}"
                    tvBeginTime.text = "Waktu Acara: ${it.beginTime}"
                    val sisaKuota = if (it.quota != null && it.registrants != null) {
                        it.quota - it.registrants
                    } else {
                        0 // Atau nilai default lain yang diinginkan
                    }
                    tvQuota.text = "Sisa Kuota: $sisaKuota"

                    // Cek apakah acara sudah favorit
                    val eventEntity = EventEntity(it.id.toString(), it.name, it.summary, /* parameter lain */)
                    checkIfFavorite(eventEntity)

                    // Setup klik listener untuk ivFavorite
                    ivFavorite.setOnClickListener {
                        viewModel.toggleFavorite(eventEntity)
                        toggleFavoriteIcon(ivFavorite, eventEntity)
                    }

                    tvLink.setOnClickListener {
                        event.link?.let { link ->
                            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(link))
                            startActivity(browserIntent)
                        }
                    }
                    showLoading(false)
                }
            }
        }
    }

    private fun checkIfFavorite(event: EventEntity) {
        viewModel.getAllEvents().observe(this) { events ->
            if (events.any { it.id == event.id }) {
                ivFavorite.setImageResource(R.drawable.baseline_favorite_24)
            } else {
                ivFavorite.setImageResource(R.drawable.baseline_favorite_border_24)
            }
        }
    }

    private fun toggleFavoriteIcon(imageView: ImageView, event: EventEntity) {
        if (viewModel.getAllEvents().value?.any { it.id == event.id } == true) {
            imageView.setImageResource(R.drawable.baseline_favorite_border_24)
        } else {
            imageView.setImageResource(R.drawable.baseline_favorite_24)
        }
    }

    private fun showLoading(isLoading: Boolean) {
        progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}
