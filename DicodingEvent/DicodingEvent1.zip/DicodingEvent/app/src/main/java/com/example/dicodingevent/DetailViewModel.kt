import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.dicodingevent.data.local.EventEntity
import com.example.dicodingevent.data.local.EventRepository
import com.example.dicodingevent.data.remote.response.DetailResponse
import com.example.dicodingevent.data.remote.response.Event
import com.example.dicodingevent.data.remote.response.EventResponse
import com.example.dicodingevent.data.remote.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import retrofit2.Response

class DetailViewModel(application: Application) : AndroidViewModel(application) {
    private val apiService = ApiConfig.getApiService()
    private val _eventDetail = MutableLiveData<Event>()
    private val mEventRepository: EventRepository = EventRepository(application)
    val eventDetail: LiveData<Event> get() = _eventDetail

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> get() = _isLoading

    fun getAllEvents(): LiveData<List<EventEntity>> = mEventRepository.getAllEvents()

    fun fetchEventDetail(id: Int) {
        _isLoading.value = true
        apiService.getDetailEvent(id.toString()).enqueue(object : Callback<DetailResponse> {
            override fun onResponse(call: Call<DetailResponse>, response: Response<DetailResponse>) {
                if (response.isSuccessful && response.body() != null) {
                    response.body()?.event.also { _eventDetail.value = it }
                }
                _isLoading.value = false
            }

            override fun onFailure(call: Call<DetailResponse>, t: Throwable) {
                _isLoading.value = false
                // Handle error
            }
        })
    }

    fun toggleFavorite(event: EventEntity) {
        val eventExists = getAllEvents().value?.any { it.id == event.id } ?: false
        if (eventExists) {
            mEventRepository.delete(event)
        } else {
            mEventRepository.insert(event)
        }
    }

}
