package com.example.dicodingevent.data.local

import android.app.Application
import androidx.lifecycle.LiveData
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class EventRepository(application: Application) {
    private val mEventsDao: EventDao
    private val executorService: ExecutorService = Executors.newSingleThreadExecutor()
    init {
        val db = EventDatabase.getDatabase(application)
        mEventsDao = db.eventDao()
    }
    fun getAllEvents(): LiveData<List<EventEntity>> = mEventsDao.getAllEvents()
    fun insert(event: EventEntity) {
        executorService.execute { mEventsDao.insert(event) }
    }
    fun delete(event: EventEntity) {
        executorService.execute { mEventsDao.delete(event) }
    }
    fun update(event: EventEntity) {
        executorService.execute { mEventsDao.update(event) }
    }
}